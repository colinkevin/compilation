package fr.ul.miage;

import fr.ul.miage.arbre.Affectation;
import fr.ul.miage.arbre.Bloc;
import fr.ul.miage.arbre.Const;
import fr.ul.miage.arbre.Ecrire;
import fr.ul.miage.arbre.Fonction;
import fr.ul.miage.arbre.Idf;
import fr.ul.miage.arbre.Lire;
import fr.ul.miage.arbre.Prog;
import fr.ul.miage.arbre.Si;
import fr.ul.miage.arbre.Superieur;
import fr.ul.miage.arbre.TxtAfficheur;

public class Exemple5 {

	public Exemple5() {
		// exemple #5 
        
        // on crée les noeuds 
        Prog prog = new Prog();
        Fonction principal = new Fonction("main");
        Affectation aff = new Affectation();
        Idf i = new Idf("i");
        Lire lire = new Lire();
        Const const1 = new Const(10);
        Const const2 = new Const(1);
        Const const3 = new Const(2);
        Superieur sup = new Superieur();
        Si si1 = new Si(3);
        Ecrire ecrire = new Ecrire();
        Ecrire ecrire2 = new Ecrire();
        Bloc bloc1 = new Bloc();
        Bloc bloc2 = new Bloc();

        // on lie les noeuds 
        prog.ajouterUnFils(principal);
        principal.ajouterUnFils(aff); 
        principal.ajouterUnFils(si1); 
        aff.setFilsGauche(i);
        aff.setFilsDroit(lire);
        si1.setCondition(sup);
        sup.setFilsGauche(i);
        sup.setFilsDroit(const3);
        si1.setBlocAlors(bloc1);
        bloc1.ajouterUnFils(ecrire);
        ecrire.ajouterUnFils(const2);
        si1.setBlocSinon(bloc2);
        bloc2.ajouterUnFils(ecrire);
        ecrire2.ajouterUnFils(const3);
        System.out.println("Exemple 5 :");
        TxtAfficheur.afficher(prog);    
	}
}
