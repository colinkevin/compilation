package fr.ul.miage;

import fr.ul.miage.arbre.Affectation;
import fr.ul.miage.arbre.Bloc;
import fr.ul.miage.arbre.Const;
import fr.ul.miage.arbre.Ecrire;
import fr.ul.miage.arbre.Fonction;
import fr.ul.miage.arbre.Idf;
import fr.ul.miage.arbre.Inferieur;
import fr.ul.miage.arbre.Plus;
import fr.ul.miage.arbre.Prog;
import fr.ul.miage.arbre.TantQue;
import fr.ul.miage.arbre.TxtAfficheur;

public class Exemple6 {
	public Exemple6() {
		// exemple #6 
        
        // on crée les noeuds 
        Prog prog = new Prog();
        Fonction principal = new Fonction("main");
        Affectation aff = new Affectation();
        Idf i = new Idf("i");
        Const const1 = new Const(0);
        TantQue tq = new TantQue(1);
        Inferieur inf = new Inferieur();
        Idf n = new Idf("n");
        Bloc bloc1 = new Bloc();
        Ecrire ecrire = new Ecrire();
        Affectation aff2 = new Affectation();
        Plus plus = new Plus();
        Const const2 = new Const(1);
        
        // on lie les noeuds 
        prog.ajouterUnFils(principal);
        principal.ajouterUnFils(aff);
        principal.ajouterUnFils(tq);
        aff.setFilsGauche(i);
        aff.setFilsDroit(const1);
           
        tq.setCondition(inf);
        inf.setFilsGauche(i);
        inf.setFilsDroit(n);
        tq.setBloc(bloc1);
        bloc1.ajouterUnFils(ecrire);
        bloc1.ajouterUnFils(aff2);
        ecrire.ajouterUnFils(i);
        aff2.setFilsGauche(i);
        aff2.setFilsDroit(plus);
        plus.setFilsGauche(i);
        plus.setFilsDroit(const2);
       
        System.out.println("Exemple 6 :");
        TxtAfficheur.afficher(prog);
	}
}
