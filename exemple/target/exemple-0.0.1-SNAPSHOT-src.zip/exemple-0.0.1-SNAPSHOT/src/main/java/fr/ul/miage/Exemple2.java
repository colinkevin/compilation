package fr.ul.miage;

import fr.ul.miage.arbre.Fonction;
import fr.ul.miage.arbre.Prog;
import fr.ul.miage.arbre.TxtAfficheur;

public class Exemple2 {
	public Exemple2() {
		Prog prog = new Prog();
		Fonction principal = new Fonction("main");
	    prog.ajouterUnFils(principal);
	    System.out.println("Exemple 2 : ");
	    TxtAfficheur.afficher(prog);
	}
}
