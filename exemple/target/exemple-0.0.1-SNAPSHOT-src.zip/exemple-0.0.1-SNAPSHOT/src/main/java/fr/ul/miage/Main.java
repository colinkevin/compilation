package fr.ul.miage;

public class Main {

public static void main( String[] args ){
		
		Exemple1 ex1 = new Exemple1();
		Exemple2 ex2 = new Exemple2();
		Exemple3 ex3 = new Exemple3();
		Exemple4 ex4 = new Exemple4();
		Exemple5 ex5 = new Exemple5();
		Exemple6 ex6 = new Exemple6();
		Exemple7 ex7 = new Exemple7();
		Exemple8 ex8 = new Exemple8();

    } 
}
