package fr.ul.miage;

import fr.ul.miage.arbre.Affectation;
import fr.ul.miage.arbre.Const;
import fr.ul.miage.arbre.Fonction;
import fr.ul.miage.arbre.Idf;
import fr.ul.miage.arbre.Multiplication;
import fr.ul.miage.arbre.Plus;
import fr.ul.miage.arbre.Prog;
import fr.ul.miage.arbre.TxtAfficheur;

public class Exemple3 {

	public Exemple3() {
        // exemple #3
        // on crée les noeuds 
		Prog prog = new Prog();
        Fonction principal = new Fonction("main");
        Affectation aff = new Affectation();
        Affectation aff2 = new Affectation();
        Idf k = new Idf("k");
        Idf l = new Idf("l");
        Idf f = new Idf("f");
        Idf j = new Idf("j");

        Const const1 = new Const(2);
        Const const2 = new Const(3);
        Plus plus = new Plus();
        Multiplication mult = new Multiplication();
        // on lie les noeuds 
        prog.ajouterUnFils(principal);
        principal.ajouterUnFils(aff);
        principal.ajouterUnFils(aff2);
        aff.setFilsGauche(k);
        aff.setFilsDroit(const1);
        aff2.setFilsGauche(l);
        aff2.setFilsDroit(plus);
        plus.setFilsGauche(f);
        plus.setFilsDroit(mult);
        mult.setFilsGauche(const2);
        mult.setFilsDroit(j);
        System.out.println("Exemple 3 :");
        TxtAfficheur.afficher(prog);
	}
}
