package fr.ul.miage;

import fr.ul.miage.arbre.Affectation;
import fr.ul.miage.arbre.Ecrire;
import fr.ul.miage.arbre.Fonction;
import fr.ul.miage.arbre.Idf;
import fr.ul.miage.arbre.Lire;
import fr.ul.miage.arbre.Plus;
import fr.ul.miage.arbre.Prog;
import fr.ul.miage.arbre.TxtAfficheur;

public class Exemple4 {
	public Exemple4() {
		 // exemple #4 
       // on crée les noeuds 
       Prog prog = new Prog();
       Fonction principal = new Fonction("main");
       Affectation aff = new Affectation();
       Idf i = new Idf("i");
       Lire lire = new Lire();
       Ecrire ecrire = new Ecrire();
       Plus plus = new Plus();
       Idf i2 = new Idf("i");
       Idf j = new Idf("j"); 
       // on lie les noeuds 
       prog.ajouterUnFils(principal);
       principal.ajouterUnFils(aff); 
       principal.ajouterUnFils(ecrire); 
       aff.setFilsGauche(i);
       aff.setFilsDroit(lire);
       ecrire.setLeFils(plus);
       plus.setFilsGauche(i2);
       plus.setFilsDroit(j);
       System.out.println("Exemple 4 :");
       TxtAfficheur.afficher(prog);
	}
}
