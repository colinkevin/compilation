package fr.ul.miage;

import fr.ul.miage.arbre.Affectation;
import fr.ul.miage.arbre.Appel;
import fr.ul.miage.arbre.Const;
import fr.ul.miage.arbre.Ecrire;
import fr.ul.miage.arbre.Fonction;
import fr.ul.miage.arbre.Idf;
import fr.ul.miage.arbre.Plus;
import fr.ul.miage.arbre.Prog;
import fr.ul.miage.arbre.TxtAfficheur;

public class Exemple7 {

	public Exemple7() {
		// exemple #7
        
        // on crée les noeuds 
        Prog prog = new Prog();
        Fonction f = new Fonction("f");
        Affectation aff = new Affectation();
        Idf x = new Idf("x");
        Const const1 = new Const(1);
        Affectation aff2 = new Affectation();
        Idf y = new Idf("y");
        Affectation aff3 = new Affectation();
        Idf a = new Idf("a");
        Plus plus = new Plus();
        Plus plus2 = new Plus();
        Idf i = new Idf("i");
        Fonction principal = new Fonction("main");
        Const const2 = new Const(3);
        Appel app = new Appel(f);
        Ecrire ecrire = new Ecrire();

        // on lie les noeuds 
        prog.ajouterUnFils(f);
        f.ajouterUnFils(aff);
        aff.setFilsGauche(x);
        aff.setFilsDroit(const1);
        f.ajouterUnFils(aff2);
        aff2.setFilsGauche(y);
        aff2.setFilsDroit(const1);
        f.ajouterUnFils(aff3);
        aff3.setFilsGauche(a);
        aff3.setFilsDroit(plus);
        plus.setFilsGauche(i);
        plus.setFilsDroit(plus2);
        plus2.setFilsGauche(x);
        plus2.setFilsDroit(y);

        prog.ajouterUnFils(principal);
        principal.ajouterUnFils(app);
        app.ajouterUnFils(const2);
        principal.ajouterUnFils(ecrire);
        ecrire.ajouterUnFils(a);
        System.out.println("Exemple 7 :");
        TxtAfficheur.afficher(prog);
	}
}
