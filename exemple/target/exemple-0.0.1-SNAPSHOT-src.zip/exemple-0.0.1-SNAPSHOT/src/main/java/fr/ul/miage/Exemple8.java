package fr.ul.miage;

import fr.ul.miage.arbre.Affectation;
import fr.ul.miage.arbre.Appel;
import fr.ul.miage.arbre.Const;
import fr.ul.miage.arbre.Ecrire;
import fr.ul.miage.arbre.Fonction;
import fr.ul.miage.arbre.Idf;
import fr.ul.miage.arbre.Plus;
import fr.ul.miage.arbre.Prog;
import fr.ul.miage.arbre.Retour;
import fr.ul.miage.arbre.TxtAfficheur;

public class Exemple8 {
	public Exemple8() {
		// exemple #8
        
        // on crée les noeuds 
        Prog prog = new Prog();
        Fonction f = new Fonction("f");
        Affectation aff = new Affectation();
        Idf x = new Idf("x");
        Plus plus = new Plus();
        Idf i = new Idf("i");
        Idf j = new Idf("j");
        Retour rt = new Retour(f);
        Plus plus2 = new Plus();
        Const const1 = new Const(10);
        Fonction principal = new Fonction("main");
        Affectation aff2 = new Affectation();
        Idf a = new Idf("a");
        Appel app = new Appel(f);
        Const const2 = new Const(1);
        Const const3 = new Const(2);
        Ecrire ecrire = new Ecrire();

        // on lie les noeuds 
        prog.ajouterUnFils(f);
        f.ajouterUnFils(aff);
        aff.setFilsGauche(x);
        aff.setFilsDroit(plus);
        plus.setFilsGauche(i);
        plus.setFilsDroit(j);
        f.ajouterUnFils(rt);
        rt.setLeFils(plus2);
        plus2.setFilsGauche(x);
        plus2.setFilsDroit(const1);
        
        prog.ajouterUnFils(principal);
        principal.ajouterUnFils(aff2);
        aff2.setFilsGauche(a);
        aff2.setFilsDroit(app);
        app.ajouterUnFils(const2);
        app.ajouterUnFils(const3);
        principal.ajouterUnFils(ecrire);
        ecrire.ajouterUnFils(a);
        System.out.println("Exemple 8 :");
        TxtAfficheur.afficher(prog);
	}
}
