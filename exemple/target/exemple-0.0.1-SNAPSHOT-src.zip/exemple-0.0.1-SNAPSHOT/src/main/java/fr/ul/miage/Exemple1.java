package fr.ul.miage;

import fr.ul.miage.arbre.Fonction;
import fr.ul.miage.arbre.Prog;
import fr.ul.miage.arbre.TxtAfficheur;

public class Exemple1 {
	public Exemple1() {
		Prog prog = new Prog();
		Fonction principal = new Fonction("main");
        prog.ajouterUnFils(principal);
        System.out.println("Exemple 1 : ");
        TxtAfficheur.afficher(prog);
}
}
